
(function () {
  if (window.__apMetaCleanPixelGuard) return;
  var BLOCKED = '1490944286382722';
  if (window.location.hostname.indexOf('.site.agendapro') === -1) return;
  window.__apMetaCleanPixelGuard = true;

  var realFbq = typeof window.fbq === 'function' ? window.fbq : undefined;
  var proxy = null;

  function ensureProxy() {
    if (proxy || !realFbq) return;
    proxy = new Proxy(realFbq, {
      apply: function (target, thisArg, args) {
        if (args[0] === 'init' && String(args[1]) === BLOCKED) return;
        return Reflect.apply(target, thisArg, args);
      },
      get: function (t, p) { return Reflect.get(realFbq, p); },
      set: function (t, p, v) { realFbq[p] = v; return true; }
    });
  }

  ensureProxy();

  Object.defineProperty(window, 'fbq', {
    configurable: true,
    get: function () {
      ensureProxy();
      return proxy;
    },
    set: function (v) {
      realFbq = v;
      proxy = null;
      ensureProxy();
    }
  });
})();
