System.register(["./assets/agendapro-root-config-C-ADfQ-X.js","single-spa"],function(e,s){"use strict";return{setters:[null,null],execute:function(){}}});
//# sourceMappingURL=agendapro-root-config.js.map
