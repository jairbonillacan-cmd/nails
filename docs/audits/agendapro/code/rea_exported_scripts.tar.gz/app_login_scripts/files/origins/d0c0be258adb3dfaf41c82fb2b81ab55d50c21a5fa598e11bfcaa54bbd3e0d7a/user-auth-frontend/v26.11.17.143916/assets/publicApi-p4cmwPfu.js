System.register(["./axios-sxQcR4sd.js"],function(s,a){"use strict";var e;return{setters:[t=>{e=t.a}],execute:function(){const t=s("A",e.create({baseURL:"https://agendapro.com",withCredentials:!0,headers:{"Content-Type":"application/json",Accept:"application/json"}}))}}});
//# sourceMappingURL=publicApi-p4cmwPfu.js.map
