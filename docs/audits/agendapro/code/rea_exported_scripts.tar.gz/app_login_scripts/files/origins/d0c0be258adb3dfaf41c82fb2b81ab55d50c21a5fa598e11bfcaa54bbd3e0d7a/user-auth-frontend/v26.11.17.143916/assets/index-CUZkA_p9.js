System.register(["./agendapro-user-auth-DBT4VI3Z.js","./index.esm-BOds3p9g.js","./analytics-I738LAFZ.js","./userAccount-Dz55hLz6.js","./index.modern-B3TCtexR.js","./utils-CeACcQht.js","./useTranslation-CqfYgpxn.js","./Trans-xDO3TRnZ.js","./axios-sxQcR4sd.js","./publicApi-p4cmwPfu.js"],function(de,w){"use strict";var n,g,E,L,$,e,i,I,A,b,R,z,O,T,P,F,H,M,V,B,D,U,W,J,Y,G,K,Q,X,j,y,q,Z,ee,te,d;return{setters:[r=>{n=r.r,g=r.d,E=r.u,L=r.k,$=r.n,e=r.j,i=r.f,I=r.H,A=r.A,b=r.$,R=r.E,z=r.b,O=r.V,T=r.c,P=r.m,F=r.C,H=r.y,M=r.X,V=r.B,B=r.o},r=>{D=r.u},r=>{U=r.e,W=r.s,J=r.f,Y=r.a,G=r.b,K=r.c,Q=r.d},r=>{X=r.l},r=>{j=r._,y=r.f},r=>{q=r.o,Z=r.b,ee=r.a},r=>{te=r.u},r=>{d=r.T},null,null],execute:function(){const r=""+new URL("carousel-1-B1k6OFhX.svg",w.meta.url).href,pe=""+new URL("carousel-2-CZGGPmyS.svg",w.meta.url).href,me=""+new URL("carousel-bg-Coz6EJTU.png",w.meta.url).href,xe=t=>{const[p,m]=n.useState(!0);return n.useEffect(()=>{const h=window.matchMedia(t);h.matches!==p&&m(h.matches);const u=()=>m(h.matches);return window.addEventListener("resize",u),()=>window.removeEventListener("resize",u)},[p,t]),p},ge=g.div`
	display: flex;

	& > div {
		border-radius: ${({theme:t})=>t.borderRadius.xl};
	}
	strong {
		color: ${({theme:t})=>t.tokens.color.text.defaultInverse};
		font-weight: 700;
	}

	P {
		text-align: center !important;
		line-height: 30px;
		font-size: 25px;
		font-weight: 300;

		@media (max-width: 1450px) {
			font-size: 18px;
		}
	}
	.left-arrow path,
	.right-arrow path {
		stroke: ${({theme:t})=>t.tokens.color.background.primary};
		fill: ${({theme:t})=>t.tokens.color.background.primary};
	}

	.item-circle {
		background-color: ${({theme:t})=>t.tokens.color.background.primary};
	}
	.selected {
		background-color: ${({theme:t})=>t.tokens.color.background.brand};
	}

	.carousel-link {
		text-decoration: underline;
		text-decoration-color: ${({theme:t})=>t.tokens.color.text.brandSoft};

		p {
			font-weight: 700;
		}
	}
`,he=g.div`
	display: flex;

	.current-item {
		max-width: 750px;
		max-height: 620px;
		width: 80%;
	}
	img {
		max-width: 370px;
		max-height: 400px;
	}
	.show-password-btn {
		cursor: pointer;
	}
`,ue=g.div`
	display: flex;
	flex-direction: column;
	height: 100vh;
	margin: auto;

	.sign-in-wrapper {
		flex-grow: 1;
		display: flex;
		flex-direction: column;
		justify-content: center;
		margin: 0 16px;
	}
	.loader {
		i {
			font-size: 15px;
		}
	}

	.agendapro-logo {
		display: block;
		margin-top: 20px;
		margin-left: auto;
		margin-right: auto;
		width: 200px;
		margin-bottom: 3rem;
	}

	.form-alert-signIn {
		display: flex;
		min-height: 34px;
		align-items: center;
		gap: ${({theme:t})=>t.spacing.sm};
		padding: ${({theme:t})=>t.spacing[8]};
		background-color: ${({theme:t})=>t.migrateColors("background.dangerSoft","alert20")};
		border: 1px solid ${({theme:t})=>t.migrateColors("border.danger","alert50")};
		border-radius: ${({theme:t})=>t.spacing.xs};
		margin-bottom: 10px;
		margin-top: ${({theme:t})=>t.spacing[8]};
		@media ${j["no-mobile"]} {
			margin-bottom: 20px;
		}
	}

	.sign-in-card {
		box-sizing: border-box;
		background: 'extraColors.white';
		width: 100%;
		min-width: 300px;
		margin: 0 auto;
		box-shadow: none;
		@media ${j["no-mobile"]} {
			width: 70%;
			max-width: 400px;
			margin: 0 auto;
		}
		.cardHeader {
			display: flex;
			flex-direction: column;
			gap: 12px;
			margin-bottom: 30px;
			.welcome-text {
				font-size: 40px;
				font-weight: 700;
				line-height: 50px;
				margin-bottom: 16px;
			}

			.secondary-text {
				font-size: 22px;
				font-weight: 400;
			}
		}

		#fieldLabel {
			font-size: 14px;
			font-weight: 500;
			color: ${({theme:t})=>t.colors.gray};
		}

		.emailField {
			margin-bottom: 10px;

			i {
				color: ${({theme:t})=>t.colors.gray80};
			}
		}
		.passwordField {
			margin-bottom: 10px;

			svg {
				color: ${({theme:t})=>t.colors.gray80};
			}
		}

		#iconPassword {
			svg {
				margin-bottom: 0;
			}
		}

		.forget-password-link {
			cursor: pointer;
			margin-bottom: 25px;
			text-decoration: underline;
			text-decoration-color: ${({theme:t})=>t.migrateColors("text.btnLink","gray50")};

			&:hover {
				p {
					color: ${({theme:t})=>t.migrateColors("text.btnLinkHover","primary")} !important;
				}
				text-decoration-color: ${({theme:t})=>t.migrateColors("text.btnLinkHover","primary")};
			}
		}

		.remember-check {
			width: 100%;
			margin-bottom: 20px;
		}

		.submit-button {
			margin: 20px 0;
			max-width: 100%;
		}
	}

	.register-wrapper {
		display: flex;
		justify-content: center;
		align-items: center;
		gap: 5px;

		.register-link {
			font-size: 14px;
			font-weight: 500;
			color: ${({theme:t})=>t.migrateColors("text.btnLink","primary")};
			text-decoration: underline ${({theme:t})=>t.migrateColors("text.btnLink","primary")};
			cursor: pointer;
		}
		.register-link:hover {
			color: ${({theme:t})=>t.migrateColors("text.btnLinkHover","primary")};
			text-decoration: underline ${({theme:t})=>t.migrateColors("text.btnLinkHover","primary")};
		}
	}

	.app-business-wrapper {
		.store-image-wrapper {
			display: flex;
			justify-content: space-around;
			margin-top: 32px;
			.app-store-image {
				width: 135px;
				height: 40px;
			}
		}
		.agendapro-business-wrapper {
			display: flex;
			align-items: center;
			justify-content: center;
			margin-top: 16px;
			gap: 10px;
		}

		@media (min-width: 768px) {
			display: none;
		}
	}

	.footer-text {
		margin-bottom: 16px;
	}
`,fe=g.form`
	padding: ${({theme:t})=>t.spacing[16]};
	border-radius: ${({theme:t})=>t.spacing[8]};
	background: ${({theme:t})=>t.tokens.color.background.primary};
	border: 1px solid ${({theme:t})=>t.tokens.color.border.primary};
`,Ne=de("default",()=>{var ie,ne,le,ce;const{register:t,setValue:p,handleSubmit:m,getValues:h,formState:{errors:u,isValid:we,isSubmitting:re}}=D({mode:"onChange"}),{t:s}=te("translation",{keyPrefix:""}),se=E(),oe=L(),{breakpoints:be,colors:je,migrateColors:l,tokens:k}=$(),ye=xe(`(min-width: ${be.xl})`),[_,C]=n.useState(!1),[v,ke]=n.useState(!1),[ae,N]=n.useState(""),[x,_e]=n.useState(""),f=k.color.text.defaultInverse,Ce=[{src:r,alt:"posnet",upperText:e.jsx("div",{className:"upper-text-wrapper",children:e.jsx(i,{className:"upper-text",color:f,children:e.jsx(d,{children:s("first_item_upper_text")})})}),lowerText:e.jsxs("div",{className:"lower-text-wrapper",children:[e.jsx(i,{className:"lower-text",color:f,children:e.jsx(d,{children:s(x==="mx"?"first_item_lower_text_mx":"first_item_lower_text")})}),e.jsx("a",{href:x==="mx"?"https://hubs.li/Q02JWYld0":"https://hubs.li/Q01YVjqn0",target:"_blank",rel:"noreferrer",className:"carousel-link",children:e.jsx(i,{color:k.color.text.brandSoft,children:s("second_item_lower_link")})})]})},{src:pe,alt:"schedule options",upperText:e.jsx("div",{className:"upper-text-wrapper",children:e.jsx(i,{className:"upper-text",color:f,children:e.jsx(d,{children:s(x==="mx"?"second_item_upper_text_mx":"second_item_upper_text")})})}),lowerText:e.jsxs("div",{className:"lower-text-wrapper",children:[e.jsx(i,{className:"lower-text",color:f,textAlign:"center",children:e.jsx(d,{children:s(x==="mx"?"second_item_lower_text_mx":"second_item_lower_text")})}),e.jsx("a",{href:x==="mx"?"https://hubs.li/Q02JWYld0":"https://hubs.li/Q01YVjqn0",target:"_blank",rel:"noreferrer",className:"carousel-link",children:e.jsx(i,{color:k.color.text.brandSoft,children:s("second_item_lower_link")})})]})}],S=async a=>{try{localStorage.removeItem("REACT_QUERY_OFFLINE_CACHE"),N(""),J("password"),Y("credentials");const o={...a,email:a.email.trim().toLowerCase(),password:a.password.trim()},c=await X(o);if(c!=null&&c.session||G(),c!=null&&c.session){localStorage.setItem("credentials",JSON.stringify({...o,session:c.session})),se("/two_factor_auth");return}_?(localStorage.setItem("credentials",JSON.stringify(h())),localStorage.setItem("isChecked","true")):(localStorage.removeItem("credentials"),localStorage.setItem("isChecked","false"))}catch(o){K("credentials",Q(o)),N(ee(o,s))}};n.useEffect(()=>{U("sign_in"),W("credentials")},[]),n.useEffect(()=>{const a=localStorage.getItem("isChecked")||"",o=a&&JSON.parse(a);C(o===null?!0:o)},[]),n.useEffect(()=>{const a=localStorage.getItem("credentials")||"",o=a&&JSON.parse(a);o&&(p("email",o==null?void 0:o.email,{shouldValidate:!0}),p("password",o==null?void 0:o.password,{shouldValidate:!0}))},[]),n.useEffect(()=>{var o;const a=(o=oe.state)==null?void 0:o.errorKey;a&&N(s(a))},[oe.state,s]);const ve=()=>{fetch("https://ipapi.co/json/").then(a=>a.json()).then(a=>{var o;_e((o=a==null?void 0:a.country_code)==null?void 0:o.toLowerCase())}).catch(()=>{})};return n.useEffect(()=>{ve()},[]),e.jsxs(he,{children:[e.jsxs(I,{children:[e.jsx("meta",{httpEquiv:"X-UA-Compatible",content:"IE=edge"}),e.jsx("meta",{name:"viewport",content:"width=device-width, initial-scale=1.0"}),e.jsx("style",{children:`body{
              padding: 0;
              margin: 0;
              background: #f0f3f4;
              color: #707070;
            }`})]}),e.jsxs(ue,{children:[e.jsxs("div",{className:"sign-in-wrapper",onKeyDown:a=>q(a,m(S)),children:[e.jsx(A,{size:30,className:"agendapro-logo"}),e.jsxs("div",{className:"sign-in-card",children:[e.jsxs("div",{className:"cardHeader",children:[e.jsx(i,{className:"welcome-text",color:l("text.default","gray"),textAlign:"center",children:s("hello")}),e.jsx(i,{className:"secondary-text",color:l("text.default","gray"),textAlign:"center",children:s("welcome")}),e.jsx(i,{type:"body",color:l("text.subtler","gray50"),textAlign:"center",children:s("enter_your_credentials")})]}),e.jsx("div",{children:e.jsxs(fe,{onSubmit:m(S),children:[e.jsx("div",{className:"emailField",children:e.jsx(b,{label:s("LABEL_EMAIL"),leftAdornment:{component:R,size:20},...t("email",y("email")),errorMsg:(ne=(ie=u.email)==null?void 0:ie.message)==null?void 0:ne.toString(),placeholder:`${s("PLACEHOLDER_EMAIL")}`,full:!0})}),e.jsx("div",{className:"passwordField",children:e.jsx(b,{label:s("LABEL_PASSWORD"),type:v?"text":"password",leftAdornment:{component:z,size:20},rightAdornment:{className:"show-password-btn",component:v?O:T,size:20,onClick:()=>ke(!v)},...t("password",y("password")),errorMsg:(ce=(le=u.password)==null?void 0:le.message)==null?void 0:ce.toString(),placeholder:`${s("PLACEHOLDER_PASSWORD")}`,full:!0})}),e.jsx("div",{className:"forget-password-link",onClick:()=>se("/reset_password"),children:e.jsx(i,{type:"p-small",color:l("text.btnLink","gray50"),children:s("LINK_FORGOT_YOUR_PASSWORD")})}),e.jsx(P,{className:"remember-check",checked:_,onChange:()=>C(!_),size:15,label:s("CHECKBOX_REMEMBER_ME")}),ae&&e.jsxs("div",{className:"form-alert-signIn",role:"alert",children:[e.jsx(F,{size:32,color:l("icon.danger","alert")}),e.jsx(i,{color:l("text.danger","alert"),children:ae})]}),e.jsx(H,{fullWidth:!0,onClick:m(S),className:"submit-button",disabled:!we||re,type:"button",children:re?e.jsx("div",{className:"loader",children:e.jsx(M,{variant:"secondary",size:"20px"})}):s("LOGIN")}),e.jsxs("div",{className:"register-wrapper",children:[e.jsx(i,{type:"body",color:l("text.default","gray80"),children:s("LINK_NO_ACCOUNT_YET")}),e.jsx("a",{onClick:()=>window.location.assign(`${Z()}/signup`),className:"register-link",children:s("REGISTER")})]})]})})]}),e.jsxs("div",{className:"app-business-wrapper",children:[e.jsxs("div",{className:"agendapro-business-wrapper",children:[e.jsx(V,{size:32}),e.jsx(i,{type:"p-small",color:je.gray80,children:e.jsx(d,{children:s("DOWNLOAD_OUR_APP")})})]}),e.jsxs("div",{className:"store-image-wrapper",children:[e.jsx("img",{loading:"lazy",onClick:()=>window.open("https://play.google.com/store/apps/details?id=com.ionicframework.agendaproappiframe903400&hl=es_CL&gl=US","_self"),src:"https://s3.us-west-2.amazonaws.com/agendaprodev.com/google_play_badge.png",alt:"playstore"}),e.jsx("img",{loading:"lazy",className:"app-store-image",onClick:()=>window.open("https://apps.apple.com/cl/app/agendapro-business/id1218956898","_self"),src:"https://agendaprodev.s3-us-west-2.amazonaws.com/emerald/assets/appstore.png",alt:"appstore"})]})]})]}),e.jsx(i,{type:"p-small",color:l("text.subtlest","gray80"),textAlign:"center",className:"footer-text",children:s("FOOTER")})]}),ye&&["cl","mx"].includes(x)&&e.jsx(ge,{children:e.jsx(B,{ItemList:Ce,backgroundImage:me})})]})})}}});
//# sourceMappingURL=index-CUZkA_p9.js.map
