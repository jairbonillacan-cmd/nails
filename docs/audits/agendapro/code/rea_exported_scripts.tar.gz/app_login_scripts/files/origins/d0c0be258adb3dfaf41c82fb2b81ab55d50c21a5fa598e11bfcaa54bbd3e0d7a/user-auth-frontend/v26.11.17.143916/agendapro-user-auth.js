System.register(["./assets/agendapro-user-auth-DBT4VI3Z.js"],function(e,s){"use strict";return{setters:[t=>{e({bootstrap:t.D,mount:t.F,unmount:t.G})}],execute:function(){}}});
//# sourceMappingURL=agendapro-user-auth.js.map
