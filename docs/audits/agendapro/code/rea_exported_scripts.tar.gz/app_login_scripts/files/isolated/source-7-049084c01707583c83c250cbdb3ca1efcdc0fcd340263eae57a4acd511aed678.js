
			(function () {
				// HotJar llama window.opener.postMessage() en cambios de ruta,
				// pero window.opener es null cuando la página no fue abierta por window.open().
				// Este fix debe ejecutarse ANTES de cargar HotJar.
				if (!window.opener) {
					try {
						// Intento 1: Usar Object.defineProperty para garantizar que persista
						Object.defineProperty(window, 'opener', {
							value: {
								postMessage: function () {
									// Implementación vacía - no hace nada
								},
								closed: false,
							},
							writable: true,
							configurable: true,
						});
					} catch (e) {
						try {
							// Intento 2: Asignación directa como fallback
							window.opener = {
								postMessage: function () {},
								closed: false,
							};
						} catch (e2) {
							// Si ambos fallan, el navegador no permite modificar window.opener
							// En este caso, el error seguirá ocurriendo pero es un caso edge muy raro
						}
					}
				}
			})();
		