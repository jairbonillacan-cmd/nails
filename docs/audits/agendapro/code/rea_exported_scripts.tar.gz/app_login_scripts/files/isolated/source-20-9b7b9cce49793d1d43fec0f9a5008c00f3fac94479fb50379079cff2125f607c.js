
			(function () {
				var isIOS =
					/iPhone|iPad|iPod/.test(navigator.userAgent) ||
					(navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);
				if (isIOS) {
					document
						.querySelector('meta[name="viewport"]')
						.setAttribute('content', 'width=device-width, initial-scale=1.0, maximum-scale=1');
				}
			})();
		