
			System.import('@agendapro/root-config');
		