
			// Configuración de rutas para GTM
			window.GTM_CONFIG = {
				allowedPaths: ['pay_plan', 'billing'],
				blockedPaths: ['/payments/'],
				checkPath: function (path) {
					path = path.toLowerCase();
					return (
						this.allowedPaths.some((allowed) => path.includes(allowed)) &&
						!this.blockedPaths.some((blocked) => path.includes(blocked))
					);
				},
			};

			// Función para manejar GTM
			window.handleGTM = function () {
				const shouldLoad = window.GTM_CONFIG.checkPath(window.location.pathname);

				if (window.gtmLoaded !== shouldLoad && shouldLoad) {
					window.gtmLoaded = true;
					(function (w, d, s, l, i) {
						w[l] = w[l] || [];
						w[l].push({ 'gtm.start': new Date().getTime(), event: 'gtm.js' });
						var f = d.getElementsByTagName(s)[0],
							j = d.createElement(s),
							dl = l != 'dataLayer' ? '&l=' + l : '';
						j.defer = true;
						j.src = 'https://www.googletagmanager.com/gtm.js?id=' + i + dl;
						f.parentNode.insertBefore(j, f);
					})(window, document, 'script', 'dataLayer', 'GTM-K2MQ8F5J');

					setTimeout(() => {
						if (!window.churnkey || !window.churnkey.created) {
							window.churnkey = { created: true };
							const a = document.createElement('script');
							a.src = 'https://assets.churnkey.co/js/app.js?appId=lrqfiz8b9';
							a.async = true;
							const b = document.getElementsByTagName('script')[0];
							b.parentNode.insertBefore(a, b);
						}
					}, 3000);
				}
			};

			// Observar cambios en la URL usando la API History
			(function (history) {
				const pushState = history.pushState;
				history.pushState = function (state) {
					const result = pushState.apply(history, arguments);
					window.handleGTM();
					return result;
				};

				window.addEventListener('popstate', function () {
					window.handleGTM();
				});
			})(window.history);

			// Verificación inicial
			window.addEventListener('load', function () {
				window.handleGTM();
			});
		