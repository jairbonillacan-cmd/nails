(function () {
  function scale() {
    var width = window.outerWidth || window.innerWidth;
    document.documentElement.style.zoom =
      width >= 3200 ? "2" : width >= 2560 ? "1.5" : width >= 2200 ? "1.25" : "";
  }
  scale();
  window.addEventListener("resize", scale);
})()